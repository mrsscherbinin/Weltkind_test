<h1 align="center" style="color: red;">Хьюстон, у нас проблемы!</h1>
<p align="center">
Кажется руки админа не такие уж и прямые...
</p>
<div class="container-fluid" align="center">
<img  src="http://cdn.yourepeat.com/media/gif/001/236/451/2e22f130d7ab036ffcbf4d2a7655ca31.gif" width="500" alt="">
</div>
</br>
<audio autoplay>
    <source src="staticfiles/404.mp3" type="audio/mp3; codecs=vorbis"/>
    <source src="staticfiles/404.mp3" type="audio/mpeg"/>
  </audio>