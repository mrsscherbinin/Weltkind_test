<?php 

define ("DBUSER", "root");
define ("DBPASS", "1221");
define ("DBNAME", "Weltkind_test");

define ("LOGIN", "admin");
define ("PASSWORD", "1221");


define ("HOME", "http://localhost/");

?>